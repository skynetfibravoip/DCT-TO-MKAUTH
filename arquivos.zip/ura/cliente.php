<?php

require('config.php');

$cpf_cnpj = $_GET['cpf_cnpj'];


$result = $db->fetch("SELECT id, nome, login, endereco, plano, contrato, bloqueado FROM `sis_cliente` WHERE cpf_cnpj = $cpf_cnpj");

if(!empty($result)){
	echo json_encode($result);
}else{
	$response = array();
	echo json_encode($response);
}


?>