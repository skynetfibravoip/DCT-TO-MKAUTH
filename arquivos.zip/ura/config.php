<?php



require('db.class.php');

$db = new db("localhost", "root", "vertrigo", "mkradius");

//Checa conexão
if(!$db->connected){
	$response =  array('sucesso'=> 0, 'mensagem'=> 'Falha na conexão com o banco de dados.');
	echo json_encode($response);
	die();
}

?>