<?php

require('config.php');

$cpf_cnpj = $_GET['cpf_cnpj'];

$status = 'aberto';//padrão
$status_id = array(0 => 'aberto', 1 => 'pago');

if(isset($_GET['status'])){
	$filtro_status = $_GET['status'];
	$status = $status_id[$filtro_status];
}

//testa se a tabela de PIX existe
$teste = $db->count("SHOW TABLES LIKE 'sis_qrpix'");

$result = array();

//Tabela não existe
if($teste == 0){
	$result = $db->fetchAll("SELECT titulo, status, tipo, plano, descricao, linhadig linha_digitavel, venc dia_vencimento, valor, desconto, acrescimo, date(datavenc) data_vencimento, date(datapag) data_pagamento FROM vtab_titulos WHERE cpf_cnpj = $cpf_cnpj AND (status = '$status' OR status = 'vencido') AND deltitulo = 0 ORDER BY `datavenc` ASC");	
}else{
	$result = $db->fetchAll("SELECT t.titulo, status, tipo, plano, descricao, linhadig linha_digitavel, qr.qrcode copiacola, venc dia_vencimento, valor, desconto, acrescimo, date(datavenc) data_vencimento, date(datapag) data_pagamento FROM vtab_titulos t LEFT JOIN sis_qrpix qr on qr.titulo = t.uuid_lanc WHERE cpf_cnpj = $cpf_cnpj AND (status = '$status' OR status = 'vencido') AND deltitulo = 0 ORDER BY `datavenc` ASC");	
}



if(!empty($result)){
	echo json_encode($result);
}else{
	$response = array();
	echo json_encode($response);
}

?>