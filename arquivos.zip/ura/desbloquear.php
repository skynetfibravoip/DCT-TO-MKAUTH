<?php

require('config.php');

$id_cliente = $_GET['id_cliente'];
$response = array();

//"UPDATE sis_cliente SET bloqueado = 'nao', rem_obs = '$data3 00:00:00', observacao = 'sim'  WHERE id = '$id_Cl'"
//INSERT INTO `sis_logs` (`registro`, `data`, `login`, `tipo`, `operacao`) VALUES ('o cliente $nome_Cl solicitou o Desbloqueio via chat - IP:127.0.0.1', '$dt', 'admin', 'chat', 'OPERNULL')"
//"DELETE FROM radreply WHERE `username` = '$nome_Serv'

//Configuração de desbloqueios
$desbloqueios = array();
$file_name = 'desbloqueios.json';
$permitir = true;
$dias_tolerancia = 30;
$dias = 3;//dias de liberação 

if(file_exists($file_name)){
	$desbloqueios = json_decode(file_get_contents($file_name), true);	
}

//Checa se foi feito desbloqueio nos últimos 30 dias
if(isset($desbloqueios[$id_cliente])){
	
	// Calcula a diferença em segundos entre as datas
	$diferenca = time() - strtotime($desbloqueios[$id_cliente]);

	//Calcula a diferença em dias
	$dif_dias = floor($diferenca / (60 * 60 * 24));
	
	if($dif_dias <= $dias_tolerancia){
		$permitir = false;		
	}
}

//Se foi feito fora dentro prazo, nega o desbloqueio
if(!$permitir){
	$response['sucesso'] = 0;
	$response['mensagem'] = "Desbloqueio negado! Você já utilizou esse recurso nos últimos $dias_tolerancia dias.";
	echo json_encode($response);
	die();
}

$data_atual = date('d/m/Y H:i:s');
$hoje = date('Y-m-d');
$data_expira = date('Y-m-d', strtotime($hoje. " + $dias days"));

$erro = false;

//Inicia transação
$db->startTransaction();

//Pega os dados do cliente
$cliente = $db->fetch("SELECT nome, login FROM `sis_cliente` WHERE id = $id_cliente");

//Faz o desbloqueio
if(!$db->update("UPDATE sis_cliente SET bloqueado = 'nao', rem_obs = '$data_expira', observacao = 'sim'  WHERE id = $id_cliente")){
	$erro = true;	
}

//Registra no log
$nome_cliente = $cliente['nome'];
if(!$db->insert("INSERT INTO `sis_logs` (`registro`, `data`, `login`, `tipo`, `operacao`) VALUES ('O cliente $nome_cliente solicitou o desbloqueio via ChatBot - James', '$data_atual', 'admin', 'chat', 'OPERNULL')")){
	$erro = true;
}

//Retira a restrição
$login_cliente = $cliente['login'];
if(!$db->delete("DELETE FROM radreply WHERE `username` = '$login_cliente'")){
	$erro = true;
}

if($erro){
	//Desfaz a transação
	$db->rollback();
	$response['sucesso'] = 0;
	$response['mensagem'] = 'Não foi possível fazer o desbloqueio.';	
}else{
	//Confirma as alterações
	$db->commit();
	$response['sucesso'] = 1;
	$response['mensagem'] = 'Desbloqueado com sucesso.';
	//Registra quando foi feito o desbloqueio
	$desbloqueios[$id_cliente] = date('Y-m-d');
	file_put_contents($file_name, json_encode($desbloqueios));
}

echo json_encode($response);

?>